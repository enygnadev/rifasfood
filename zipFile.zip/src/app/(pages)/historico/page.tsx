
import HistoricoPage from "./HistoricoPage";
export default HistoricoPage;
