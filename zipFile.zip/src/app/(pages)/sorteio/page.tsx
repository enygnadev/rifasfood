
import SorteioPage from "./SorteioPage";
export default SorteioPage;
