export { default } from "./ContagemPage";
