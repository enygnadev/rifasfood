export function logInfo(...args: any[]) { console.log('[rifafood]', ...args); }
export function logWarn(...args: any[]) { console.warn('[rifafood]', ...args); }
export function logError(...args: any[]) { console.error('[rifafood]', ...args); }
